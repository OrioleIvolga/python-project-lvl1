#!/usr/bin/env python


from brain_games.even_number import main


if __name__ == "__main__":
    main()
