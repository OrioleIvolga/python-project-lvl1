from random import randint
import prompt


def game_event_number():
	print("Answer `yes` if the number is evev, otherwise answer `no`")
	number = 