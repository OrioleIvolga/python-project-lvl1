impotr prompt

def welcome_user():
    name = prompt.string("May I have yuor name? ")
    print("Hallo, " + "name")
    
